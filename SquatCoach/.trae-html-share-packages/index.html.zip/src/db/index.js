import Dexie from 'dexie'

class SquatDB extends Dexie {
  constructor() {
    super('squat-coach-db')
    this.version(1).stores({
      records: '++id, createdAt, totalCount, poseScore',
    })
  }
}

export const db = new SquatDB()

export async function saveRecord(record) {
  record.createdAt = record.createdAt || Date.now()
  return await db.records.add(record)
}

export async function getAllRecords() {
  return await db.records.orderBy('createdAt').reverse().toArray()
}

export async function deleteRecord(id) {
  return await db.records.delete(id)
}

export async function clearAllRecords() {
  return await db.records.clear()
}

export async function importRecords(records) {
  await db.records.bulkAdd(records, { allKeys: true })
}

export async function exportAllRecords() {
  const records = await getAllRecords()
  return {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    records,
  }
}
