// MediaPipe Pose is an IIFE that attaches to window.Pose
import '@mediapipe/pose'
const Pose = typeof window !== 'undefined' ? window.Pose : null

// MediaPipe Pose landmark indices
const LM = {
  NOSE: 0,
  LEFT_SHOULDER: 11, RIGHT_SHOULDER: 12,
  LEFT_HIP: 23,   RIGHT_HIP: 24,
  LEFT_KNEE: 25,  RIGHT_KNEE: 26,
  LEFT_ANKLE: 27, RIGHT_ANKLE: 28,
  LEFT_HEEL: 29,  RIGHT_HEEL: 30,
}

class PoseAnalyzer {
  constructor() {
    this.pose = null
    this.initialized = false
  }

  async init() {
    if (this.initialized) return this

    this.pose = new Pose({
      locateFile: (file) =>
        `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5.1675469404/${file}`,
    })

    this.pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5,
    })

    this.initialized = true
    return this
  }

  /**
   * 分析视频文件
   * @param {File} videoFile - 视频文件
   * @param {function} onProgress - 进度回调 (percent, currentFrame, totalFrames) => void
   * @returns {Promise<object>} 分析结果
   */
  async analyzeVideo(videoFile, onProgress) {
    await this.init()

    // 用 URL 加载视频
    const url = URL.createObjectURL(videoFile)
    const video = document.createElement('video')
    video.src = url
    video.muted = true
    video.playbackRate = 1.0

    await new Promise((resolve, reject) => {
      video.onloadedmetadata = resolve
      video.onerror = reject
    })

    const duration = video.duration
    const fps = 30 // 以30fps采样
    const totalFrames = Math.floor(duration * fps)
    const frameInterval = 1 / fps

    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth || 640
    canvas.height = video.videoHeight || 480
    const ctx = canvas.getContext('2d')

    // 收集所有帧的关键点
    const allLandmarks = []
    let frameIdx = 0

    try {
      // 使用 requestAnimationFrame 逐帧推进
      await new Promise((resolve, reject) => {
        video.onseeked = async () => {
          if (frameIdx % 5 === 0 && onProgress) {
            onProgress(Math.round((frameIdx / totalFrames) * 100), frameIdx, totalFrames)
          }

          // 绘制当前帧
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

          // 推理
          try {
            const result = await this.pose.send({ image: canvas })
            if (result && result.poseLandmarks) {
              allLandmarks.push({
                frame: frameIdx,
                time: frameIdx * frameInterval * 1000, // ms
                landmarks: result.poseLandmarks,
              })
            } else {
              allLandmarks.push(null)
            }
          } catch (e) {
            allLandmarks.push(null)
          }

          frameIdx++
          if (frameIdx >= totalFrames) {
            resolve()
          } else {
            try {
              video.currentTime = frameIdx * frameInterval
            } catch (e) {
              resolve()
            }
          }
        }

        video.onerror = reject
        try {
          video.currentTime = 0
        } catch (e) {
          resolve()
        }
      })
    } finally {
      URL.revokeObjectURL(url)
    }

    // 分析阶段
    const analysis = this.analyzeLandmarks(allLandmarks, fps)
    analysis.keypoints = allLandmarks.filter(k => k !== null)

    return analysis
  }

  /**
   * 分析关键点序列，得出计数和姿势评判
   */
  analyzeLandmarks(frameData, fps) {
    // 过滤掉 null 帧
    const validFrames = frameData.filter(f => f !== null)
    if (validFrames.length < 5) {
      return {
        totalCount: 0,
        repTimestamps: [],
        rhythmStats: { fastest: 0, slowest: 0, average: 0 },
        poseScore: 0,
        poseRating: 'need_improve',
        poseDimensions: this.getDefaultDimensions(),
        keypoints: [],
      }
    }

    // 每帧提取关键数据：髋部y、膝盖y、髋-膝距离等
    const features = validFrames.map(f => this.extractFeatures(f.landmarks))

    // 深蹲计数
    const countResult = this.countSquats(features, validFrames)

    // 找到最深帧用于姿势评判
    const deepestFrameIdx = this.findDeepestFrameIdx(features)
    const deepestLandmarks = validFrames[deepestFrameIdx]?.landmarks

    // 姿势评判
    const poseResult = deepestLandmarks
      ? this.evaluatePose(deepestLandmarks, features)
      : { dimensions: this.getDefaultDimensions(), score: 0, rating: 'need_improve' }

    return {
      totalCount: countResult.totalCount,
      repTimestamps: countResult.repTimestamps,
      rhythmStats: countResult.rhythmStats,
      poseScore: poseResult.score,
      poseRating: poseResult.rating,
      poseDimensions: poseResult.dimensions,
      keypoints: validFrames,
    }
  }

  /**
   * 从 landmarks 提取特征
   */
  extractFeatures(landmarks) {
    const hipL = landmarks[LM.LEFT_HIP]
    const hipR = landmarks[LM.RIGHT_HIP]
    const kneeL = landmarks[LM.LEFT_KNEE]
    const kneeR = landmarks[LM.RIGHT_KNEE]
    const ankleL = landmarks[LM.LEFT_ANKLE]
    const ankleR = landmarks[LM.RIGHT_ANKLE]
    const shoulderL = landmarks[LM.LEFT_SHOULDER]
    const shoulderR = landmarks[LM.RIGHT_SHOULDER]

    const hipY = (hipL.y + hipR.y) / 2
    const hipX = (hipL.x + hipR.x) / 2
    const kneeY = (kneeL.y + kneeR.y) / 2
    const kneeX = (kneeL.x + kneeR.x) / 2
    const ankleY = (ankleL.y + ankleR.y) / 2
    const ankleX = (ankleL.x + ankleR.x) / 2
    const shoulderY = (shoulderL.y + shoulderR.y) / 2
    const shoulderX = (shoulderL.x + shoulderR.x) / 2

    return { hipY, hipX, kneeY, kneeX, ankleY, ankleX, shoulderY, shoulderX }
  }

  /**
   * 深蹲计数算法
   */
  countSquats(features, validFrames) {
    if (features.length < 5) {
      return { totalCount: 0, repTimestamps: [], rhythmStats: { fastest: 0, slowest: 0, average: 0 } }
    }

    // 1. 平滑髋部y坐标（移动平均窗口）
    const WINDOW = 5
    const smoothed = features.map((_, i) => {
      const start = Math.max(0, i - WINDOW)
      const end = Math.min(features.length, i + WINDOW + 1)
      let sum = 0, count = 0
      for (let j = start; j < end; j++) {
        sum += features[j].hipY
        count++
      }
      return sum / count
    })

    // 2. 计算基线（站立时髋部y）：取最小的20%值平均
    const sorted = [...smoothed].sort((a, b) => a - b)
    const baseline = sorted.slice(0, Math.max(1, Math.floor(sorted.length * 0.15))).reduce((a, b) => a + b, 0) / Math.max(1, Math.floor(sorted.length * 0.15))

    // 3. 计算动态阈值（下蹲判定 = baseline + delta）
    const deltaOverall = smoothed.reduce((a, b) => a + b, 0) / smoothed.length - baseline
    const SQUAT_THRESHOLD = baseline + deltaOverall * 0.45 // 下蹲深度阈值

    // 4. 找波峰（站立点，hipY接近baseline）和波谷（下蹲点，hipY超过阈值）
    const state = {
      phase: 'standing', // 'standing' -> 'squatting' -> 'standing' = 1次
      squatStartIdx: -1,
      peaks: [], // 站立点
      valleys: [], // 下蹲点
    }

    for (let i = 1; i < smoothed.length - 1; i++) {
      const cur = smoothed[i]
      const prev = smoothed[i - 1]
      const next = smoothed[i + 1]

      if (state.phase === 'standing') {
        // 检测进入下蹲：hipY超过阈值
        if (cur > SQUAT_THRESHOLD && cur > prev) {
          state.phase = 'squatting'
          state.squatStartIdx = i
        }
      } else if (state.phase === 'squatting') {
        // 检测波谷（最深点）：局部最大
        if (cur > prev && cur > next && cur > SQUAT_THRESHOLD) {
          if (state.valleys.length === 0 || i - state.valleys[state.valleys.length - 1] > 5) {
            state.valleys.push(i)
          }
        }
        // 检测回到站立：hipY回到baseline附近
        if (cur < baseline + deltaOverall * 0.1) {
          state.phase = 'standing'
          state.peaks.push(i)
        }
      }
    }

    // 5. 配对：完整深蹲 = 谷点 + 站立点
    const repTimestamps = []
    const MIN_FRAMES = 8 // 最小持续帧数（过滤抖动）

    for (const valleyIdx of state.valleys) {
      // 找到该谷点之后最近的站立点
      const nextPeak = state.peaks.find(p => p > valleyIdx && p - valleyIdx > MIN_FRAMES)
      // 找到该谷点之前最近的起始点
      const prevPeak = state.peaks.filter(p => p < valleyIdx).pop()

      if (prevPeak && nextPeak) {
        const repStart = validFrames[prevPeak]?.time || prevPeak * 33
        const repEnd = validFrames[nextPeak]?.time || nextPeak * 33

        // 确保下蹲确实达到了一定深度
        const valleyHipY = smoothed[valleyIdx]
        if (valleyHipY > SQUAT_THRESHOLD) {
          repTimestamps.push({
            start: Math.round(repStart),
            end: Math.round(repEnd),
            frameStart: prevPeak,
            frameEnd: nextPeak,
          })
        }
      }
    }

    // 去重：相邻两次间隔小于1秒的合并
    const filtered = []
    for (const rep of repTimestamps) {
      const last = filtered[filtered.length - 1]
      if (!last || rep.start - last.end > 500) {
        filtered.push(rep)
      }
    }

    // 节奏统计
    const durations = filtered.map(r => r.end - r.start)
    let rhythmStats = { fastest: 0, slowest: 0, average: 0 }
    if (durations.length > 0) {
      rhythmStats = {
        fastest: Math.round(Math.min(...durations)),
        slowest: Math.round(Math.max(...durations)),
        average: Math.round(durations.reduce((a, b) => a + b, 0) / durations.length),
      }
    }

    return {
      totalCount: filtered.length,
      repTimestamps: filtered,
      rhythmStats,
    }
  }

  /**
   * 找到最深帧索引
   */
  findDeepestFrameIdx(features) {
    let maxHipY = -1
    let maxIdx = -1
    for (let i = 0; i < features.length; i++) {
      if (features[i].hipY > maxHipY) {
        maxHipY = features[i].hipY
        maxIdx = i
      }
    }
    return maxIdx
  }

  /**
   * 姿势评判（5个维度）
   */
  evaluatePose(landmarks, allFeatures) {
    const L = (i) => landmarks[i]

    // 关键点
    const hipL = L(LM.LEFT_HIP), hipR = L(LM.RIGHT_HIP)
    const kneeL = L(LM.LEFT_KNEE), kneeR = L(LM.RIGHT_KNEE)
    const ankleL = L(LM.LEFT_ANKLE), ankleR = L(LM.RIGHT_ANKLE)
    const shoulderL = L(LM.LEFT_SHOULDER), shoulderR = L(LM.RIGHT_SHOULDER)

    // 平均值
    const hipY = (hipL.y + hipR.y) / 2
    const hipX = (hipL.x + hipR.x) / 2
    const kneeY = (kneeL.y + kneeR.y) / 2
    const kneeX = (kneeL.x + kneeR.x) / 2
    const ankleY = (ankleL.y + ankleR.y) / 2
    const ankleX = (ankleL.x + ankleR.x) / 2
    const shoulderY = (shoulderL.y + shoulderR.y) / 2
    const shoulderX = (shoulderL.x + shoulderR.x) / 2

    // ---- 维度1: 下蹲深度 ----
    // y坐标越大 = 画面越低。髋部y >= 膝盖y 说明蹲得够深
    const isDeepEnough = hipY >= kneeY - 0.02 // 允许2%容差
    const depth = isDeepEnough
      ? { status: 'ok', detail: '下蹲深度达标，大腿接近或低于水平线', suggestion: '' }
      : { status: 'warn', detail: `髋部比膝盖高约 ${Math.round((kneeY - hipY) * 100)}%，蹲得偏浅`,
          suggestion: '下蹲时想象要坐到身后的椅子上，确保大腿与地面平行或更低' }

    // ---- 维度2: 膝盖方向（左右对称度）----
    // 比较左右膝-髋连线与水平方向的角度
    const kneeOffsetL = kneeL.x - hipL.x // 正值=膝在髋右
    const kneeOffsetR = hipR.x - kneeR.x // 正值=膝在髋左
    const kneeDirDiff = Math.abs(kneeOffsetL - kneeOffsetR)
    const kneeDirOK = kneeDirDiff < 0.15
    const kneeDir = kneeDirOK
      ? { status: 'ok', detail: '膝盖方向与髋部对齐正常', suggestion: '' }
      : kneeOffsetL > kneeOffsetR
        ? { status: 'warn', detail: '左侧膝盖似乎有内扣倾向',
            suggestion: '注意膝盖与脚尖方向一致，下蹲时膝盖向外打开' }
        : { status: 'warn', detail: '右侧膝盖似乎有内扣倾向',
            suggestion: '注意膝盖与脚尖方向一致，下蹲时膝盖向外打开' }

    // ---- 维度3: 膝盖过脚尖 ----
    // 侧面视角需要，但这里用左右对比粗略判断
    const kneeOverreach = Math.abs(kneeX - ankleX)
    const ankleToAnkle = Math.abs(ankleL.x - ankleR.x) || 0.3
    const kneeOverRatio = kneeOverreach / ankleToAnkle
    const kneeOverOK = kneeOverRatio < 0.8
    const kneeOver = kneeOverOK
      ? { status: 'ok', detail: '膝盖未过度超过脚尖', suggestion: '' }
      : { status: 'warn', detail: '膝盖相对脚尖的前移量较大',
          suggestion: '下蹲时重心后移到脚跟，注意膝盖不要超过脚尖太多' }

    // ---- 维度4: 背部挺直度 ----
    // 肩-髋-膝 夹角（接近180度=挺直）
    const backAngle = this.calcAngle(
      { x: shoulderX, y: shoulderY },
      { x: hipX, y: hipY },
      { x: kneeX, y: kneeY }
    )
    const backOK = backAngle >= 150
    const back = backOK
      ? { status: 'ok', detail: `背部挺直度良好（夹角约${Math.round(backAngle)}°）`, suggestion: '' }
      : { status: 'warn', detail: `背部有弯曲（夹角约${Math.round(backAngle)}°）`,
          suggestion: '保持核心收紧，想象头顶向上延伸，避免弓背或塌腰' }

    // ---- 维度5: 身体前倾 ----
    // 肩-髋连线与垂直方向的夹角
    const leanAngle = Math.abs(
      Math.atan2(Math.abs(shoulderX - hipX), hipY - shoulderY) * 180 / Math.PI
    )
    const leanOK = leanAngle < 45
    const lean = leanOK
      ? { status: 'ok', detail: `身体前倾角度正常（约${Math.round(leanAngle)}°）`, suggestion: '' }
      : { status: 'warn', detail: `身体前倾较多（约${Math.round(leanAngle)}°）`,
          suggestion: '保持躯干直立，核心收紧，必要时可以扶墙练习平衡' }

    const dimensions = { depth, kneeDir, kneeOver, back, lean }

    // 计算评分
    let score = 0
    const keys = Object.keys(dimensions)
    const okCount = keys.filter(k => dimensions[k].status === 'ok').length
    score = Math.round(okCount * 20)

    // 额外加分/扣分
    if (backAngle >= 160 && backAngle <= 180) score += 3
    if (depth.status === 'ok') score += 2
    if (leanAngle < 30) score += 2
    score = Math.min(100, score)

    let rating = 'need_improve'
    if (score >= 90) rating = 'excellent'
    else if (score >= 75) rating = 'good'
    else if (score >= 60) rating = 'pass'

    return { dimensions, score, rating }
  }

  /**
   * 计算三点的夹角（中间点为顶点）
   */
  calcAngle(a, b, c) {
    const v1x = a.x - b.x, v1y = a.y - b.y
    const v2x = c.x - b.x, v2y = c.y - b.y
    const dot = v1x * v2x + v1y * v2y
    const mag1 = Math.sqrt(v1x * v1x + v1y * v1y)
    const mag2 = Math.sqrt(v2x * v2x + v2y * v2y)
    const cos = Math.max(-1, Math.min(1, dot / (mag1 * mag2 + 1e-8)))
    return Math.acos(cos) * 180 / Math.PI
  }

  getDefaultDimensions() {
    return {
      depth:    { status: 'warn', detail: '未检测到有效人体', suggestion: '请确保全身入镜，光线充足' },
      kneeDir:  { status: 'warn', detail: '未检测到有效人体', suggestion: '请确保全身入镜，光线充足' },
      kneeOver: { status: 'warn', detail: '未检测到有效人体', suggestion: '请确保全身入镜，光线充足' },
      back:     { status: 'warn', detail: '未检测到有效人体', suggestion: '请确保全身入镜，光线充足' },
      lean:     { status: 'warn', detail: '未检测到有效人体', suggestion: '请确保全身入镜，光线充足' },
    }
  }
}

export const poseAnalyzer = new PoseAnalyzer()

// MediaPipe 骨架连接线（用于绘制）
export const POSE_CONNECTIONS = [
  [11, 12], [11, 23], [12, 24], [23, 24],       // 躯干
  [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], // 左臂
  [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], // 右臂
  [23, 25], [25, 27], [27, 29], [27, 31], [29, 31],            // 左腿
  [24, 26], [26, 28], [28, 30], [28, 32], [30, 32],            // 右腿
]
